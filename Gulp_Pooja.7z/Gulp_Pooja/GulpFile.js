/**
 * Created by kaudutta on 11/9/2016.
 */
var gulp   = require('gulp');

var jshint = require('gulp-jshint');
var uglify=require('gulp-uglify');
var sass = require('gulp-sass');
var rename=require('gulp-rename');




gulp.task('lint', function() {
    return gulp.src('app.js')
        .pipe(jshint())
        .pipe(jshint.reporter('default'));
});

gulp.task('minify',function () {
    return gulp.src("app.js")
        .pipe(uglify())
        .pipe(gulp.dest('build'))

});

gulp.task('sass', function () {
    gulp.src('sample.scss')
    /*.pipe(sass())*/
        .pipe(sass().on('error', sass.logError))
        .pipe(gulp.dest('build'));
});

gulp.task('rename',function () {
    return gulp.src("app.js")
        .pipe(rename('appnew.js'))
        .pipe(gulp.dest('build'))





});
