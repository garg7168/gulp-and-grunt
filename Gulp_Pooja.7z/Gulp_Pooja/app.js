/**
 * Created by kaudutta on 11/9/2016.
 */
var app=angular.module("myApp",[]);
app.controller("myCtrl",function ($scope) {
    $scope.myName="Pooja Aggarwal"
});