/**
 * Created by kaudutta on 11/7/2016.
 */
module.exports = function(grunt) { //wrapper function
    grunt.initConfig({
        pkg: grunt.file.readJSON('node_modules/grunt/package.json'),
        jshint: {
            options: {
               reporter: require('jshint-stylish') // use jshint-stylish to make our errors look and read good
            },

            // when this task is run, lint the Gruntfile and all js files in src
            build: ['GruntFile.js', 'app.js']
        },
        uglify: {
           /* options: {
               /!* banner: '/!*\n <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd") %> \n*!/\n'*!/
            },*/
            build: {
                files: {
                    'dist/app.min.js': 'app.js'
                }
            }
        }



    });
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-uglify');

};

