/**
 * Created by kaudutta on 11/7/2016.
 */
var app=angular.module("myApp",[]);
app.controller("myCtrl",function($scope)
{
    $scope.apps="being awesome";
});
var hello = 'look im grunting!';

var awesome = 'yes it is awesome!';

